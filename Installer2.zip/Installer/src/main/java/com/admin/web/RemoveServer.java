package com.admin.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Servlet implementation class RemoveServer
 */

public class RemoveServer extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String jdbcUrl = "jdbc:mysql://localhost:3306/mysqlInstaller?allowPublicKeyRetrieval=true&useSSL=false";
    private String username = "root";
    private String password = "#Ironman2003";
    private String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    protected Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(jdbcUrl, username, password);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return conn;
    }
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RemoveServer() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			removeServer(request, response);	
			}
	private void removeServer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int serverId = Integer.parseInt(request.getParameter("id"));

        try (Connection connection = getConnection()) {
            String sql = "SELECT location,status FROM server WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, serverId);
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    String location = resultSet.getString("location");
                    String status = resultSet.getString("status");
                    
                    if ("on".equals(status)) {
						
                    	ProcessBuilder stopProcessBuilder = new ProcessBuilder("mysqladmin", "--socket=" + location + "/mysql.sock", "-u root", "shutdown");
                    	try {
                    		stopProcessBuilder.start();
                    	} catch (IOException e) {
                    		// If the server is not running or cannot be stopped, ignore and proceed
                    	}
					}


                    // Delete server files
                    File directory = new File(location);
                    deleteDirectory(directory);

                    // Remove entry from database
                    String deleteSql = "DELETE FROM server WHERE id = ?";
                    try (PreparedStatement deleteStatement = connection.prepareStatement(deleteSql)) {
                        deleteStatement.setInt(1, serverId);
                        deleteStatement.executeUpdate();
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.sendRedirect("list");
    }

    private boolean deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (!deleteDirectory(file)) {
                        return false;
                    }
                }
            }
        }
        return directory.delete();
    }
}
