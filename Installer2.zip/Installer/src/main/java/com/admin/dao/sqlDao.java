//package com.admin.dao;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//
//import com.admin.model.ServerModel;
//
//public class sqlDao {
//	
//	 private String jdbcUrl = "jdbc:mysql://10.252.10.35:3306/sqlInstaller?useSSL=false";
//	    private String username = "root";
//	    private String password = "#Ironman2003";
//	    private String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
//	    private static int PORT_RANGE_START = 4406;
//	    private static final int PORT_RANGE_END = 5500;
//	    
//	    private static final String INSERT_server="INSERT INTO server (version, server_name, location, port_number) VALUES (?, ?, ?, ?)";
//	    private static final String SELECT_COUNT_PORT = "SELECT COUNT(*) FROM server WHERE port_number = ? ;";
//	    
//	    
//	    protected Connection getConnection() {
//	   	 Connection conn =null;
//	   	 try {
//	   		 Class.forName(JDBC_DRIVER);
//	   		 conn = DriverManager.getConnection(URL, USER, PASSWORD);
//	   	 }catch(SQLException e) {
//	   		 e.printStackTrace();
//	   	 }catch(ClassNotFoundException e) {
//	   		 e.printStackTrace();
//	   	 }	 
//	   	 
//	   	 return conn;
//	   	 
//	    }
//	    
//	    
//	    public void InsertServer(ServerModel serverModel) throws SQLException {
//	   	 
//	    	 try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
//	             String sql = "INSERT INTO server (version, server_name, location, port_number) VALUES (?, ?, ?, ?)";
//	             try (PreparedStatement statement = connection.prepareStatement(sql)) {
//	                 statement.setString(1, version);
//	                 statement.setString(2, serverName);
//	                 statement.setString(3, location);
//	                 statement.setInt(4, port);
//	                 statement.executeUpdate();
//	             }
//	         } catch (SQLException e) {
//	             e.printStackTrace();
//	         }
//	   	 
//	    }
//	    
//	    public int findAvailablePort() {
//	        for (int port = PORT_RANGE_START; port <= PORT_RANGE_END; port++) {
//	            if (!isPortInUse(port)) {
//	                return port;
//	            }
//	        }
//	        return -1;
//	    }
//
//	    private boolean isPortInUse(int port) {
//	        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
//	            String sql = "SELECT COUNT(*) FROM server WHERE port_number = ?";
//	            try (PreparedStatement statement = connection.prepareStatement(sql)) {
//	                statement.setInt(1, port);
//	                ResultSet resultSet = statement.executeQuery();
//	                if (resultSet.next()) {
//	                    int count = resultSet.getInt(1);
//	                    return count > 0;
//	                }
//	            }
//	        } catch (SQLException e) {
//	            e.printStackTrace();
//	        }
//	        return false;
//	    }
//	    
//	    
//	    
//}
