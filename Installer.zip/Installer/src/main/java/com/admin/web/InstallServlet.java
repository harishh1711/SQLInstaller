	package com.admin.web;
	
	import java.io.IOException;
	import java.io.PrintWriter;
	import java.nio.file.Files;
	import java.nio.file.Paths;
	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;
	import jakarta.servlet.ServletException;
	import jakarta.servlet.annotation.WebServlet;
	import jakarta.servlet.http.HttpServlet;
	import jakarta.servlet.http.HttpServletRequest;
	import jakarta.servlet.http.HttpServletResponse;
	
	@WebServlet("/install")
	public class InstallServlet extends HttpServlet {
	    private static final long serialVersionUID = 1L;
	    private static int PORT_RANGE_START = 4406;
	    private static final int PORT_RANGE_END = 5500;
	    private static final String MYSQL_DOWNLOAD_URL = "https://dev.mysql.com/get/Downloads/MySQL-";
	    private static final String MYSQL_TAR_XZ_EXTENSION = "-linux-glibc2.12-x86_64.tar.xz";
	    private static final String MYSQL_BIN_DIRECTORY = "bin";
	
	    private String jdbcUrl = "jdbc:mysql://localhost:3306/mysqlInstaller?allowPublicKeyRetrieval=true&useSSL=false";
	    private String username = "root";
	    private String password = "#Ironman2003";
	
	    protected void  doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	        String version = request.getParameter("version");
	        String location = request.getParameter("location");
	        String serverName = request.getParameter("server_name");
	        location += "/" + serverName + "/mysql/";
	
	        // Create the location directory if it does not exist
	        new java.io.File(location).mkdirs();
	
	        int port = findAvailablePort();
	        if (port == -1) {
	            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "No available port found");
	            return;
	        }
	
	        createMyCnf(location, port);
	
	
	        String sudoPassword = "ironman2003";
	        String command = "echo " + sudoPassword + " | sudo -S wget " + MYSQL_DOWNLOAD_URL + version + "/mysql-" + version + MYSQL_TAR_XZ_EXTENSION + " && " +
	                         "echo " + sudoPassword + " | sudo -S mkdir -p " + location + " && " +
	                         "echo " + sudoPassword + " | sudo -S tar -xvf mysql-" + version + MYSQL_TAR_XZ_EXTENSION + " -C " + location + " --strip-components=1 && " +
	                         "echo "+ sudoPassword +  " | sudo mkdir -p " + location + "data && " +
	                         "echo "+ sudoPassword +  " | sudo touch " + location + "mysqld.sock && " +
	
	                         "echo " + sudoPassword + " | sudo -S chown -R mysql:mysql " + location + " && " +
	                         "sudo chmod -R 777 " + location + "data && " +
	                         "echo "+ sudoPassword +  " | sudo touch " + location + "my.cnf && " +

	                         "cd " + location + " && " +
	                         "echo " + sudoPassword + " | sudo -S " + MYSQL_BIN_DIRECTORY + "/mysqld --datadir=" + location + "data --initialize --user=mysql && " +
	                         "echo " + sudoPassword + " | sudo -S " + MYSQL_BIN_DIRECTORY + "/mysql_ssl_rsa_setup --defaults-file=" + location + "my.cnf";
	
	        ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", command);
	        processBuilder.inheritIO();
	        Process process = processBuilder.start();
	
	        try {
	            process.waitFor();
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	
	        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
	            String sql = "INSERT INTO server (version, server_name, location, port_number) VALUES (?, ?, ?, ?)";
	            try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                statement.setString(1, version);
	                statement.setString(2, serverName);
	                statement.setString(3, location);
	                statement.setInt(4, port);
	                statement.executeUpdate();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.println("<html><body>");
	        out.println("<h1>MySQL Installation Completed</h1>");
	        out.println("<p>Version: " + version + "</p>");
	        out.println("<p>Location: " + location + "</p>");
	        out.println("</body></html>");
	    }
	
	    private int findAvailablePort() {
	        for (int port = PORT_RANGE_START; port <= PORT_RANGE_END; port++) {
	            if (!isPortInUse(port)) {
	                return port;
	            }
	        }
	        return -1;
	    }
	
	    private boolean isPortInUse(int port) {
	        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
	            String sql = "SELECT COUNT(*) FROM server WHERE port_number = ?";
	            try (PreparedStatement statement = connection.prepareStatement(sql)) {
	                statement.setInt(1, port);
	                ResultSet resultSet = statement.executeQuery();
	                if (resultSet.next()) {
	                    int count = resultSet.getInt(1);
	                    return count > 0;
	                }
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return false;
	    }
	
	    private void createMyCnf(String location, int port) {
	        String myCnfPath = location + "/my.cnf";
	        String dataDir = location + "/data";
	        String socketFile = location + "/mysql.sock";
	        String lcMessagesDir = location + "/share";
	
	        String myCnfContent = "[mysqld]\n" +
	                "basedir=" + location + "\n" +
	                "datadir=" + dataDir + "\n" +
	                "port=" + port + "\n" +
	                "socket=" + socketFile + "\n" +
	                "lc-messages-dir=" + lcMessagesDir + "\n" +
	                "\n" +
	                "[client]\n" +
	                "port=" + port + "\n" +
	                "socket=" + socketFile + "\n";
	
	        try {
	            Files.createDirectories(Paths.get(dataDir));
	            Files.createDirectories(Paths.get(lcMessagesDir));
	            Files.write(Paths.get(myCnfPath), myCnfContent.getBytes());
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
	
	    private void createDataDirectory(String location) {
	        String dataDir = location + "data";
	        try {
	            Files.createDirectories(Paths.get(dataDir));
	            String sudoPassword = "ironman2003";
	            String command = "echo " + sudoPassword + " | sudo -S chown -R mysql:mysql " + dataDir + " && " +
	                             "sudo chmod -R 777 " + dataDir;
	            ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", command);
	            processBuilder.inheritIO();
	            Process process = processBuilder.start();
	            process.waitFor();
	        } catch (IOException | InterruptedException e) {
	            e.printStackTrace();
	        }
	    }
	    
	   
	}