package com.admin.web;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/list")
public class ListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String jdbcUrl = "jdbc:mysql://localhost:3306/mysqlInstaller?allowPublicKeyRetrieval=true&useSSL=false";
    private String username = "root";
    private String password = "#Ironman2003";
    private String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    protected Connection getConnection() {
        Connection conn = null;
        try {
            Class.forName(JDBC_DRIVER);
            conn = DriverManager.getConnection(jdbcUrl, username, password);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return conn;
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>MySQL Server List</h1>");
        out.println("<table border='1'><tr><th>Version</th><th>Server Name</th><th>Location</th><th>Port</th><th>Status</th><th>Actions</th></tr>");

        try (Connection connection = getConnection()) {
            String sql = "SELECT id, version, server_name, location, port_number, status FROM server";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String version = resultSet.getString("version");
                    String serverName = resultSet.getString("server_name");
                    String location = resultSet.getString("location");
                    int port = resultSet.getInt("port_number");
                    String status = resultSet.getString("status");
                    out.println("<tr>");
                    out.println("<td>" + version + "</td>");
                    out.println("<td>" + serverName + "</td>");
                    out.println("<td>" + location + "</td>");
                    out.println("<td>" + port + "</td>");
                    out.println("<td>" + status + "</td>");
                    out.println("<td>");
                    out.println("<form action='list' method='post'>");
                    out.println("<input type='hidden' name='id' value='" + id + "'/>");
                    out.println("<input type='hidden' name='location' value='" + location + "'/>");
                    if ("off".equalsIgnoreCase(status)) {
                        out.println("<input type='hidden' name='action' value='start'/>");
                        out.println("<input type='submit' value='Start'/>");
                    } else {
                        out.println("<input type='hidden' name='action' value='stop'/>");
                        out.println("<input type='submit' value='Stop'/>");
                    }
                    out.println("</form>");
                    out.println("<form action='list' method='post'>");
                    out.println("<input type='hidden' name='id' value='" + id + "'/>");
                    out.println("<input type='hidden' name='location' value='" + location + "'/>");
                    out.println("<input type='hidden' name='action' value='remove'/>");
                    out.println("<input type='submit' value='Remove'/>");
                    out.println("</form>");
                    out.println("</td>");
                    out.println("</tr>");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        out.println("</table>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        switch (action) {
            case "start":
                startServer(request, response);
                break;
            case "stop":
                stopServer(request, response);
                break;
            case "remove":
                removeServer(request, response);
                break;
            default:
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                break;
        }
    }

    private void startServer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String location = request.getParameter("location");
        
        int port = getPort(id);

        String sudoPassword = "ironman2003";
        String startCommand = "echo " + sudoPassword + " | sudo -S " + location + "/bin/mysqld --datadir=" + location + "/data --port="++" &";

        try {
            Process process = Runtime.getRuntime().exec(new String[]{"/bin/bash", "-c", startCommand});
            process.waitFor(5, TimeUnit.MINUTES);

            updateServerStatus(id, "on");

            response.sendRedirect("list");
        } catch (InterruptedException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to start server: " + e.getMessage());
        }
    }

    private void stopServer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String location = request.getParameter("location");

        String sudoPassword = "ironman2003";
        String stopCommand = "echo " + sudoPassword + " | sudo -S " + location + "/mysql/bin/mysqladmin --defaults-file=" + location + "/mysql/my.cnf shutdown";

        try {
        	
            Process process = Runtime.getRuntime().exec(new String[]{"/bin/bash", "-c", stopCommand});
            process.waitFor(5, TimeUnit.MINUTES);

            updateServerStatus(id, "off");

            response.sendRedirect("list");
        } catch (InterruptedException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to stop server: " + e.getMessage());
        }
    }

    private void removeServer(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String location = request.getParameter("location");

        String sudoPassword = "ironman2003";
        String deleteCommand = "echo " + sudoPassword + " | sudo -S rm -r " + location;

        try {
        	  ProcessBuilder processBuilder = new ProcessBuilder("/bin/bash", "-c", deleteCommand);
  	        processBuilder.inheritIO();
  	        Process process = processBuilder.start();
//            Process process = Runtime.getRuntime().exec(new String[]{"/bin/bash", "-c", deleteCommand});
            process.waitFor(5, TimeUnit.MINUTES);

            try (Connection connection = getConnection()) {
                String sql = "DELETE FROM server WHERE id = ?";
                try (PreparedStatement statement = connection.prepareStatement(sql)) {
                    statement.setInt(1, id);
                    statement.executeUpdate();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            

            // Delete server files
            File directory = new File(location);
            deleteDirectory(directory);

            response.sendRedirect("list");
        } catch (InterruptedException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to remove server: " + e.getMessage());
        }
    }

    private void updateServerStatus(int id, String status) {
        try (Connection connection = getConnection()) {
            String sql = "UPDATE server SET status = ? WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, status);
                statement.setInt(2, id);
                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean deleteDirectory(File directory) {
        if (directory.isDirectory()) {
            File[] files = directory.listFiles();
            if (files != null) {
                for (File file : files) {
                    if (!deleteDirectory(file)) {
                        return false;
                    }
                }
            }
        }
        return directory.delete();
    }
    
    private int getPort(int id) {
    	int port = 0 ;
    	try (Connection connection = getConnection()) {
    		
            String sql = "SELECT port_number FROM server WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, id);
                ResultSet rs =statement.executeQuery();
                while(rs.next()) {
                     port = rs.getInt("port_number");

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    	
    	return port;
    	
    }
    
}

